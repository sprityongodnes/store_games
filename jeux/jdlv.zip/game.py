import pygame
import numpy as np
import sys

pygame.init()
pygame.font.init()

ecran_largeur, ecran_hauteur = 1000, 800
fenetre = pygame.display.set_mode((ecran_largeur, ecran_hauteur), pygame.RESIZABLE)
pygame.display.set_caption("Jeu de la Vie - Menu")

VERT = (0, 255, 0)
NOIR = (10, 10, 10)
GRIS = (40, 40, 40)
BLANC = (255, 255, 255)
BLEU = (50, 50, 255)
JAUNE = (255, 255, 0)

font = pygame.font.SysFont(None, 30)

taille_cellule = 10
nb_cellules_x = 300
nb_cellules_y = 300
grille = np.zeros((nb_cellules_y, nb_cellules_x), dtype=int)
offset_x, offset_y = 0, 0
pause = True

touches = {
    'haut': pygame.K_UP,
    'bas': pygame.K_DOWN,
    'gauche': pygame.K_LEFT,
    'droite': pygame.K_RIGHT
}

etat_jeu = "menu"

def dessiner_texte(texte, x, y, couleur=BLANC):
    surface = font.render(texte, True, couleur)
    fenetre.blit(surface, (x, y))

def bouton(texte, x, y, w, h, couleur, survol, action):
    souris = pygame.mouse.get_pos()
    clic = pygame.mouse.get_pressed()[0]
    if x < souris[0] < x + w and y < souris[1] < y + h:
        pygame.draw.rect(fenetre, survol, (x, y, w, h))
        if clic:
            return action
    else:
        pygame.draw.rect(fenetre, couleur, (x, y, w, h))
    dessiner_texte(texte, x + 10, y + 10)
    return None

def inserer_planeur(x, y):
    coords = [(1, 0), (2, 1), (0, 2), (1, 2), (2, 2)]
    for dx, dy in coords:
        if 0 <= y + dy < nb_cellules_y and 0 <= x + dx < nb_cellules_x:
            grille[y + dy][x + dx] = 1

def inserer_clignoteur(x, y):
    coords = [(0, 1), (1, 1), (2, 1)]
    for dx, dy in coords:
        if 0 <= y + dy < nb_cellules_y and 0 <= x + dx < nb_cellules_x:
            grille[y + dy][x + dx] = 1

def dessiner_grille():
    for y in range(ecran_hauteur // taille_cellule + 2):
        for x in range(ecran_largeur // taille_cellule + 2):
            gx = x + offset_x
            gy = y + offset_y
            if 0 <= gx < nb_cellules_x and 0 <= gy < nb_cellules_y:
                couleur = VERT if grille[gy][gx] == 1 else NOIR
                rect = pygame.Rect(x * taille_cellule, y * taille_cellule, taille_cellule - 1, taille_cellule - 1)
                pygame.draw.rect(fenetre, couleur, rect)

def mise_a_jour():
    global grille
    nouvelle = np.copy(grille)
    for y in range(1, nb_cellules_y - 1):
        for x in range(1, nb_cellules_x - 1):
            voisins = np.sum(grille[y - 1:y + 2, x - 1:x + 2]) - grille[y][x]
            if grille[y][x] == 1 and (voisins < 2 or voisins > 3):
                nouvelle[y][x] = 0
            elif grille[y][x] == 0 and voisins == 3:
                nouvelle[y][x] = 1
    grille = nouvelle

def afficher_instructions():
    lignes = [
        "[ESPACE] Démarrer / Pause",
        "[Clic gauche] Créer cellule",
        "[Clic droit] Supprimer cellule",
        "[Molette ou +/-] Zoom",
        "[ZQSD ou flèches] Déplacement"
    ]
    for i, ligne in enumerate(lignes):
        dessiner_texte(ligne, 10, 10 + i * 20)

def boucle_menu():
    global etat_jeu
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    fenetre.fill(GRIS)
    dessiner_texte("JEU DE LA VIE", 400, 100, JAUNE)

    actions = [
        bouton("▶ JOUER", 400, 200, 200, 50, BLEU, VERT, "jouer"),
        bouton("⚙ OPTIONS", 400, 280, 200, 50, BLEU, VERT, "options"),
        bouton("🧩 EXEMPLES", 400, 360, 200, 50, BLEU, VERT, "exemples"),
        bouton("❌ QUITTER", 400, 440, 200, 50, BLEU, VERT, "quitter")
    ]

    for action in actions:
        if action:
            if action == "quitter":
                pygame.quit()
                sys.exit()
            else:
                etat_jeu = action

def boucle_options():
    global etat_jeu
    fenetre.fill(GRIS)
    dessiner_texte("OPTIONS - Appuie sur une touche pour changer", 200, 50)

    y = 150
    for nom in touches:
        dessiner_texte(f"{nom.upper()} : {pygame.key.name(touches[nom])}", 300, y)
        y += 40

    dessiner_texte("Appuie sur [ECHAP] pour revenir", 300, y + 20)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                etat_jeu = "menu"
            else:
                touches['haut'] = event.key

def boucle_exemples():
    global etat_jeu
    fenetre.fill(GRIS)
    dessiner_texte("EXEMPLES - Cliquez pour insérer", 320, 50)
    dessiner_texte("Planeur : P", 320, 120)
    dessiner_texte("Clignoteur : C", 320, 160)
    dessiner_texte("Retour [ECHAP]", 320, 240)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                etat_jeu = "menu"
            elif event.key == pygame.K_p:
                inserer_planeur(10, 10)
                etat_jeu = "jouer"
            elif event.key == pygame.K_c:
                inserer_clignoteur(20, 10)
                etat_jeu = "jouer"

def boucle_jeu():
    global pause, taille_cellule, offset_x, offset_y, etat_jeu

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                pause = not pause
            elif event.key == pygame.K_q:
                pygame.quit()
                sys.exit()
            elif event.key == pygame.K_ESCAPE:
                etat_jeu = "menu"
            elif event.key in (pygame.K_PLUS, pygame.K_KP_PLUS):
                taille_cellule = min(40, taille_cellule + 1)
            elif event.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
                taille_cellule = max(2, taille_cellule - 1)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 4:
                taille_cellule = min(40, taille_cellule + 1)
            elif event.button == 5:
                taille_cellule = max(2, taille_cellule - 1)

    keys = pygame.key.get_pressed()
    if keys[touches['haut']] or keys[pygame.K_UP]:
        offset_y = max(0, offset_y - 1)
    if keys[touches['bas']] or keys[pygame.K_DOWN]:
        offset_y = min(nb_cellules_y - 1, offset_y + 1)
    if keys[touches['gauche']] or keys[pygame.K_LEFT]:
        offset_x = max(0, offset_x - 1)
    if keys[touches['droite']] or keys[pygame.K_RIGHT]:
        offset_x = min(nb_cellules_x - 1, offset_x + 1)

    mx, my = pygame.mouse.get_pos()
    gx = mx // taille_cellule + offset_x
    gy = my // taille_cellule + offset_y
    if pygame.mouse.get_pressed()[0]:
        if 0 <= gx < nb_cellules_x and 0 <= gy < nb_cellules_y:
            grille[gy][gx] = 1
    if pygame.mouse.get_pressed()[2]:
        if 0 <= gx < nb_cellules_x and 0 <= gy < nb_cellules_y:
            grille[gy][gx] = 0

    fenetre.fill(GRIS)
    dessiner_grille()
    afficher_instructions()
    if not pause:
        mise_a_jour()

# Boucle principale
clock = pygame.time.Clock()
while True:
    if etat_jeu == "menu":
        boucle_menu()
    elif etat_jeu == "options":
        boucle_options()
    elif etat_jeu == "exemples":
        boucle_exemples()
    elif etat_jeu == "jouer":
        boucle_jeu()

    pygame.display.flip()
    clock.tick(15)
