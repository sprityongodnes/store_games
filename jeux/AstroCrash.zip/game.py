﻿import pygame
import random
import sys
import time
import os

# Initialisation
pygame.init()
LARGEUR, HAUTEUR = 1000, 1000
ecran = pygame.display.set_mode((LARGEUR, HAUTEUR))
pygame.display.set_caption("AstroCrash")
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 40)
font_titre = pygame.font.SysFont(None, 80)

# Couleurs
BLANC = (255, 255, 255)
NOIR = (0, 0, 0)
ROUGE = (255, 0, 0)
VERT = (0, 255, 0)

game_folder = os.path.dirname(__file__)

# KodamiManager
class KodamiManager:
    def __init__(self, dossier="kodami"):
        self.dossier = os.path.join(game_folder, dossier)
        self.actif = False
        self.charger_textures()

    def charger_image(self, nom, taille=None):
        chemin = os.path.join(self.dossier if self.actif else game_folder, nom)
        try:
            image = pygame.image.load(chemin).convert_alpha()
            if taille:
                image = pygame.transform.scale(image, taille)
            return image
        except:
            print(f"Erreur de chargement : {nom}")
            sys.exit()

    def activer(self):
        self.actif = not self.actif
        self.charger_textures()

    def charger_textures(self):
        global vaisseau_img, asteroide_img, boost_img
        global background_img, menu_image, intro_image

        vaisseau_img = self.charger_image("vaisseau.png", (60, 60))
        asteroide_img = self.charger_image("asteroide.png", (50, 50))
        boost_img = self.charger_image("boost.png", (40, 40))
        background_img = self.charger_image("background.png", (LARGEUR, HAUTEUR))
        menu_image = self.charger_image("menu_image.png", (LARGEUR, HAUTEUR))
        intro_image = self.charger_image("intro_image.png", (LARGEUR, HAUTEUR))

kodami = KodamiManager()

# Musique
def charger_musique():
    try:
        musique_path = os.path.join(game_folder, "musique.mp3")
        pygame.mixer.music.load(musique_path)
        pygame.mixer.music.play(-1)
    except pygame.error:
        print("Erreur : musique manquante.")
        sys.exit()

charger_musique()

# Meilleur score
def charger_meilleur_score():
    if os.path.exists("meilleur_score.txt"):
        with open("meilleur_score.txt", "r") as f:
            return int(f.read())
    return 0

def sauvegarder_meilleur_score(score):
    with open("meilleur_score.txt", "w") as f:
        f.write(str(score))

meilleur_score = charger_meilleur_score()

# Fonctions affichage
def afficher_texte(texte, taille, couleur, y_offset=0):
    police = pygame.font.SysFont(None, taille)
    rendu = police.render(texte, True, couleur)
    rect = rendu.get_rect(center=(LARGEUR // 2, HAUTEUR // 2 + y_offset))
    ecran.blit(rendu, rect)

def afficher_menu_principal(selection):
    ecran.blit(background_img, (0, 0))
    ecran.blit(menu_image, (0, 0))
  
    if selection == 0:
        afficher_texte("> Jouer", 40, BLANC, 50)
        afficher_texte("Quitter", 40, BLANC, 100)
    elif selection == 1:
        afficher_texte("Jouer", 40, BLANC, 50)
        afficher_texte("> Quitter", 40, BLANC, 100)
    pygame.display.flip()

def afficher_menu_pause():
    ecran.fill(NOIR)
    afficher_texte("Pause", 80, BLANC, -150)
    afficher_texte("1. Reprendre", 40, BLANC, 0)
    afficher_texte("2. Menu principal", 40, BLANC, 50)
    pygame.display.flip()

def afficher_intro():
    ecran.blit(intro_image, (0, 0))
    afficher_texte("Appuyez sur Entrée pour commencer", 40, BLANC, 100)
    pygame.display.flip()
    attente = True
    while attente:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    attente = False

def afficher_game_over(score):
    ecran.fill(NOIR)
    afficher_texte("💥 GAME OVER 💥", 64, ROUGE, -40)
    afficher_texte(f"Score : {score}", 48, BLANC, 20)
    pygame.display.flip()
    time.sleep(3)

# Jeu principal
def lancer_jeu():
    global meilleur_score
    joueur_x, joueur_y = LARGEUR//2 - 30, HAUTEUR - 80
    joueur_vitesse = 7
    blocs, vitesse_bloc, frequence_bloc = [], 5, 10
    boost_x, boost_y, boost_visible, boost_timer = -100, -100, False, 0
    next_boost_time = random.randint(600, 1200)
    boost_duration, invincible = 180, False
    boosts_stockes, max_boosts = 0, 1
    score, frame = 0, 0
    bg_y1, bg_y2, bg_vitesse = 0, -HAUTEUR, 2
    pause, running = False, True

    while running:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_0:
                    kodami.activer()

        if pause:
            afficher_menu_pause()
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_1: pause = False
                    elif event.key == pygame.K_2: return
            continue

        # Contrôles
        touches = pygame.key.get_pressed()
        if touches[pygame.K_LEFT] and joueur_x > 0: joueur_x -= joueur_vitesse
        if touches[pygame.K_RIGHT] and joueur_x < LARGEUR - 60: joueur_x += joueur_vitesse
        if touches[pygame.K_UP] and joueur_y > 0: joueur_y -= joueur_vitesse
        if touches[pygame.K_DOWN] and joueur_y < HAUTEUR - 60: joueur_y += joueur_vitesse
        if touches[pygame.K_p]: pause = True
        if touches[pygame.K_e] and boosts_stockes > 0:
            invincible = True
            boost_timer = boost_duration
            boosts_stockes -= 1

        if score % 500 == 0 and score > 0:
            vitesse_bloc += 1
            if frequence_bloc > 10: frequence_bloc -= 2
            score += 1

        if frame % frequence_bloc == 0:
            blocs.append([random.randint(0, LARGEUR - 50), -50])
        frame += 1
        score += 1

        if not boost_visible and frame >= next_boost_time:
            boost_x, boost_y = random.randint(0, LARGEUR - 40), -40
            boost_visible = True

        # Déplacement
        blocs = [[x, y+vitesse_bloc] for x, y in blocs if y < HAUTEUR]
        if boost_visible:
            boost_y += 4
            if boost_y > HAUTEUR:
                boost_visible = False
                next_boost_time = frame + random.randint(600, 1200)

        joueur_rect = pygame.Rect(joueur_x, joueur_y, 60, 60)
        boost_rect = pygame.Rect(boost_x, boost_y, 40, 40)

        if boost_visible and joueur_rect.colliderect(boost_rect):
            boost_visible = False
            next_boost_time = frame + random.randint(600, 1200)
            if boosts_stockes < max_boosts: boosts_stockes += 1

        if not invincible:
            for x, y in blocs:
                if joueur_rect.colliderect(pygame.Rect(x, y, 50, 50)):
                    if score > meilleur_score:
                        meilleur_score = score
                        sauvegarder_meilleur_score(meilleur_score)
                    afficher_game_over(score)
                    return

        # Fond défilant
        bg_y1 += bg_vitesse
        bg_y2 += bg_vitesse
        if bg_y1 >= HAUTEUR: bg_y1 = -HAUTEUR
        if bg_y2 >= HAUTEUR: bg_y2 = -HAUTEUR
        ecran.blit(background_img, (0, bg_y1))
        ecran.blit(background_img, (0, bg_y2))

        if invincible:
            boost_timer -= 1
            if boost_timer % 10 < 5:
                ecran.blit(vaisseau_img, (joueur_x, joueur_y))
            if boost_timer <= 0:
                invincible = False
        else:
            ecran.blit(vaisseau_img, (joueur_x, joueur_y))

        for x, y in blocs: ecran.blit(asteroide_img, (x, y))
        if boost_visible: ecran.blit(boost_img, (boost_x, boost_y))

        ecran.blit(font.render(f"Score : {score}", True, BLANC), (10, 10))
        ecran.blit(font.render(f"Top : {meilleur_score}", True, BLANC), (LARGEUR - 150, 10))
        for i in range(boosts_stockes):
            ecran.blit(boost_img, (LARGEUR - 150 + (i * 45), 60))

        if invincible:
            pygame.draw.rect(ecran, VERT, (LARGEUR // 2 - 100, 20, 200, 10))
            pygame.draw.rect(ecran, ROUGE, (LARGEUR // 2 - 100, 20, (boost_timer / boost_duration) * 200, 10))

        pygame.display.flip()

# Menu principal
def menu_principal():
    selection = 0
    while True:
        afficher_menu_principal(selection)
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN and selection < 1: selection += 1
                elif event.key == pygame.K_UP and selection > 0: selection -= 1
                elif event.key == pygame.K_RETURN:
                    if selection == 0: lancer_jeu()
                    elif selection == 1: pygame.quit(); sys.exit()

# Lancer le jeu
if __name__ == "__main__":
    afficher_intro()
    menu_principal()